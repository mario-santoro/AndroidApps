package e.franc.tris;

import android.app.AlertDialog;
import android.app.Fragment;
import android.app.FragmentManager;
import android.app.FragmentTransaction;
import android.content.DialogInterface;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

public class MainActivity extends AppCompatActivity {

    FragmentManager fm;
    FragmentTransaction ft;
    TrisX tx;
    TrisO to;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        fm = getFragmentManager();
        ft = fm.beginTransaction();

        tx = new TrisX();
        to = new TrisO();

        tx.setO(to);
        to.setX(tx);


        Fragment trisX = tx;
        int idX = getResources().getIdentifier("frameTris0", "id", getPackageName());

        Fragment trisO = to;
        int idO = getResources().getIdentifier("frameTris1", "id", getPackageName());

        ft.add(idX, trisX, null);
        ft.add(idO, trisO, null);

        ft.commit();
    }

    public void newGamePlus(View v){
        AlertDialog.Builder dialog = new AlertDialog.Builder(this);
        dialog.setTitle("New Game?");
        dialog.setMessage("Vuoi iniziare una nuova partita?").setPositiveButton("SI", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {
                tx.newGamePlusPlus();
                to.newGamePlusPlusPlus();
            }
        })
                .setNegativeButton("NO", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                    }
                });
        AlertDialog alert = dialog.create();
        alert.show();
    }
}