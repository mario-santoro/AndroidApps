package e.franc.tris;

import android.app.Fragment;
import android.content.Context;
import android.os.Bundle;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.Toast;

import java.util.ArrayList;

public class TrisX extends Fragment implements View.OnClickListener{

    private TrisO o;
    private boolean myTourn = true;

    public TrisX(){}

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View v = inflater.inflate(R.layout.tris, container, false);

        ArrayList<View> allButtons;
        allButtons = (v.findViewById(R.id.trisTable)).getTouchables();

        for (View element: allButtons) {
            Button b = (Button) element;
            b.setOnClickListener(this);
            b.setTextColor(0xFFFF0000);
        }

        return v;
    }

    public void setO(TrisO o){
        this.o = o;
    }

    public void onClick(View v) {

        if(myTourn){
            Button b = (Button) v;
            int n = 0 ;

            switch(b.getId()){
                case R.id.b1: b.setText("X"); n = 1; b.setEnabled(false); break;
                case R.id.b2: b.setText("X"); n = 2; b.setEnabled(false); break;
                case R.id.b3: b.setText("X"); n = 3; b.setEnabled(false); break;
                case R.id.b4: b.setText("X"); n = 4; b.setEnabled(false); break;
                case R.id.b5: b.setText("X"); n = 5; b.setEnabled(false); break;
                case R.id.b6: b.setText("X"); n = 6; b.setEnabled(false); break;
                case R.id.b7: b.setText("X"); n = 7; b.setEnabled(false); break;
                case R.id.b8: b.setText("X"); n = 8; b.setEnabled(false); break;
                case R.id.b9: b.setText("X"); n = 9; b.setEnabled(false); break;
            }
            o.updateO("X", n);
            myTourn = false;
        }
        else {
            Context context = getActivity().getApplicationContext();
            Toast t = Toast.makeText(context, "Tocca al giocatore O", Toast.LENGTH_SHORT);
            t.setGravity(Gravity.CENTER_VERTICAL,0,-23);
            t.show();
        }
        iWin();

    }

    //funzione per essere aggiornati dall'altro frame su quale pulsante inserire il simbolo 0 e quale pulsante disabilitare
    public void updateX(String text, int n){
        switch(n){
            case 1:Button b1 = getActivity().findViewById(R.id.b1);
                b1.setText(text); b1.setEnabled(false); break;
            case 2:Button b2 = getActivity().findViewById(R.id.b2);
                b2.setText(text); b2.setEnabled(false); break;
            case 3:Button b3 = getActivity().findViewById(R.id.b3);
                b3.setText(text); b3.setEnabled(false); break;
            case 4:Button b4 = getActivity().findViewById(R.id.b4);
                b4.setText(text); b4.setEnabled(false); break;
            case 5:Button b5 = getActivity().findViewById(R.id.b5);
                b5.setText(text); b5.setEnabled(false); break;
            case 6:Button b6 = getActivity().findViewById(R.id.b6);
                b6.setText(text); b6.setEnabled(false); break;
            case 7:Button b7 = getActivity().findViewById(R.id.b7);
                b7.setText(text); b7.setEnabled(false); break;
            case 8:Button b8 = getActivity().findViewById(R.id.b8);
                b8.setText(text); b8.setEnabled(false); break;
            case 9:Button b9 = getActivity().findViewById(R.id.b9);
                b9.setText(text); b9.setEnabled(false); break;
        }
        myTourn = true;

        o.iWin();
    }

    public void endGame(){
        ArrayList<View> allButtons;
        allButtons = (getActivity().findViewById(R.id.trisTable)).getTouchables();

        for (View element: allButtons) {
            Button b = (Button) element;
            b.setEnabled(false);
        }


    }

    public void winText(){
        Context context = getActivity().getApplicationContext();
        Toast t = Toast.makeText(context, "Giocatore X vince", Toast.LENGTH_SHORT);
        t.setGravity(Gravity.CENTER_VERTICAL,0,-23);
        t.show();
        endGame();
        o.endGame();
    }

    public void iWin() {

        Button b1 = getActivity().findViewById(R.id.b1); Button b2 = getActivity().findViewById(R.id.b2);
        Button b3 = getActivity().findViewById(R.id.b3); Button b4 = getActivity().findViewById(R.id.b4);
        Button b5 = getActivity().findViewById(R.id.b5); Button b6 = getActivity().findViewById(R.id.b6);
        Button b7 = getActivity().findViewById(R.id.b7); Button b8 = getActivity().findViewById(R.id.b8);
        Button b9 = getActivity().findViewById(R.id.b9);

        if(b1.getText().equals("X") && b2.getText().equals("X") && b3.getText().equals("X"))
            winText();
        if(b1.getText().equals("X") && b4.getText().equals("X") && b7.getText().equals("X"))
            winText();
        if(b1.getText().equals("X") && b5.getText().equals("X") && b9.getText().equals("X"))
            winText();
        if(b2.getText().equals("X") && b5.getText().equals("X") && b8.getText().equals("X"))
            winText();
        if(b3.getText().equals("X") && b6.getText().equals("X") && b9.getText().equals("X"))
            winText();
        if(b3.getText().equals("X") && b5.getText().equals("X") && b7.getText().equals("X"))
            winText();
        if(b4.getText().equals("X") && b5.getText().equals("X") && b6.getText().equals("X"))
            winText();
        if(b7.getText().equals("X") && b8.getText().equals("X") && b9.getText().equals("X"))
            winText();
    }

    public void newGamePlusPlus() {

        Button b1 = getActivity().findViewById(R.id.b1); Button b2 = getActivity().findViewById(R.id.b2);
        Button b3 = getActivity().findViewById(R.id.b3); Button b4 = getActivity().findViewById(R.id.b4);
        Button b5 = getActivity().findViewById(R.id.b5); Button b6 = getActivity().findViewById(R.id.b6);
        Button b7 = getActivity().findViewById(R.id.b7); Button b8 = getActivity().findViewById(R.id.b8);
        Button b9 = getActivity().findViewById(R.id.b9);

        b1.setText(" ");b1.setEnabled(true);
        b2.setText(" ");b2.setEnabled(true);
        b3.setText(" ");b3.setEnabled(true);
        b4.setText(" ");b4.setEnabled(true);
        b5.setText(" ");b5.setEnabled(true);
        b6.setText(" ");b6.setEnabled(true);
        b7.setText(" ");b7.setEnabled(true);
        b8.setText(" ");b8.setEnabled(true);
        b9.setText(" ");b9.setEnabled(true);

        myTourn = true;
    }
}
