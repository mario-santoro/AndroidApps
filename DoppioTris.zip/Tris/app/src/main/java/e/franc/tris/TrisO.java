package e.franc.tris;

import android.app.Fragment;
import android.content.Context;
import android.os.Bundle;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.Toast;

import java.util.ArrayList;

public class TrisO extends Fragment implements View.OnClickListener{

    private TrisX x;
    private boolean myTourn = false;
    public TrisO(){ }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View v = inflater.inflate(R.layout.tris2, container, false);

        ArrayList<View> allButtons;
        allButtons = (v.findViewById(R.id.trisTable1)).getTouchables();

        for (View element: allButtons) {
            Button b = (Button) element;
            b.setOnClickListener(this);
            b.setTextColor(0xFFFF0000);
        }

        return v;
    }

    public void setX(TrisX x){
        this.x = x;
    }

    public void onClick(View v) {

        if (myTourn){
            Button a = (Button) v;
            int n = 0 ;

            switch(a.getId()){
                case R.id.a1: a.setText("O"); n = 1; a.setEnabled(false); break;
                case R.id.a2: a.setText("O"); n = 2; a.setEnabled(false); break;
                case R.id.a3: a.setText("O"); n = 3; a.setEnabled(false); break;
                case R.id.a4: a.setText("O"); n = 4; a.setEnabled(false); break;
                case R.id.a5: a.setText("O"); n = 5; a.setEnabled(false); break;
                case R.id.a6: a.setText("O"); n = 6; a.setEnabled(false); break;
                case R.id.a7: a.setText("O"); n = 7; a.setEnabled(false); break;
                case R.id.a8: a.setText("O"); n = 8; a.setEnabled(false); break;
                case R.id.a9: a.setText("O"); n = 9; a.setEnabled(false); break;
            }
            x.updateX("O", n);
            myTourn = false;
        }
        else {
            Context context = getActivity().getApplicationContext();
            Toast t = Toast.makeText(context, "Tocca al giocatore X", Toast.LENGTH_SHORT);
            t.setGravity(Gravity.CENTER_VERTICAL,0,-23);
            t.show();
        }

        iWin();
    }

    public  void updateO(String text, int n){
        switch(n){
            case 1:Button a1 = getActivity().findViewById(R.id.a1);
                a1.setText(text); a1.setEnabled(false); break;
            case 2:Button a2 = getActivity().findViewById(R.id.a2);
                a2.setText(text); a2.setEnabled(false); break;
            case 3:Button a3 = getActivity().findViewById(R.id.a3);
                a3.setText(text); a3.setEnabled(false); break;
            case 4:Button a4 = getActivity().findViewById(R.id.a4);
                a4.setText(text); a4.setEnabled(false); break;
            case 5:Button a5 = getActivity().findViewById(R.id.a5);
                a5.setText(text); a5.setEnabled(false); break;
            case 6:Button a6 = getActivity().findViewById(R.id.a6);
                a6.setText(text); a6.setEnabled(false); break;
            case 7:Button a7 = getActivity().findViewById(R.id.a7);
                a7.setText(text); a7.setEnabled(false); break;
            case 8:Button a8 = getActivity().findViewById(R.id.a8);
                a8.setText(text); a8.setEnabled(false); break;
            case 9:Button a9 = getActivity().findViewById(R.id.a9);
                a9.setText(text); a9.setEnabled(false); break;
        }
        myTourn = true;
        x.iWin();
    }

    public void endGame(){
        ArrayList<View> allButtons;
        allButtons = (getActivity().findViewById(R.id.trisTable1)).getTouchables();

        for (View element: allButtons) {
            Button b = (Button) element;
            b.setEnabled(false);
        }


    }

    public void winText(){
        Context context = getActivity().getApplicationContext();
        Toast t = Toast.makeText(context, "Giocatore O vince", Toast.LENGTH_SHORT);
        t.setGravity(Gravity.CENTER_VERTICAL,0,-23);
        t.show();
        endGame();
        x.endGame();
    }

    public void iWin() {

        Button a1 = getActivity().findViewById(R.id.a1); Button a2 = getActivity().findViewById(R.id.a2);
        Button a3 = getActivity().findViewById(R.id.a3); Button a4 = getActivity().findViewById(R.id.a4);
        Button a5 = getActivity().findViewById(R.id.a5); Button a6 = getActivity().findViewById(R.id.a6);
        Button a7 = getActivity().findViewById(R.id.a7); Button a8 = getActivity().findViewById(R.id.a8);
        Button a9 = getActivity().findViewById(R.id.a9);

        if(a1.getText().equals("O") && a2.getText().equals("O") && a3.getText().equals("O"))
            winText();
        if(a1.getText().equals("O") && a4.getText().equals("O") && a7.getText().equals("O"))
            winText();
        if(a1.getText().equals("O") && a5.getText().equals("O") && a9.getText().equals("O"))
            winText();
        if(a2.getText().equals("O") && a5.getText().equals("O") && a8.getText().equals("O"))
            winText();
        if(a3.getText().equals("O") && a6.getText().equals("O") && a9.getText().equals("O"))
            winText();
        if(a3.getText().equals("O") && a5.getText().equals("O") && a7.getText().equals("O"))
            winText();
        if(a4.getText().equals("O") && a5.getText().equals("O") && a6.getText().equals("O"))
            winText();
        if(a7.getText().equals("O") && a8.getText().equals("O") && a9.getText().equals("O"))
            winText();
    }

    public void newGamePlusPlusPlus()
    {
        Button a1 = getActivity().findViewById(R.id.a1); Button a2 = getActivity().findViewById(R.id.a2);
        Button a3 = getActivity().findViewById(R.id.a3); Button a4 = getActivity().findViewById(R.id.a4);
        Button a5 = getActivity().findViewById(R.id.a5); Button a6 = getActivity().findViewById(R.id.a6);
        Button a7 = getActivity().findViewById(R.id.a7); Button a8 = getActivity().findViewById(R.id.a8);
        Button a9 = getActivity().findViewById(R.id.a9);

        a1.setText(" ");a1.setEnabled(true);
        a2.setText(" ");a2.setEnabled(true);
        a3.setText(" ");a3.setEnabled(true);
        a4.setText(" ");a4.setEnabled(true);
        a5.setText(" ");a5.setEnabled(true);
        a6.setText(" ");a6.setEnabled(true);
        a7.setText(" ");a7.setEnabled(true);
        a8.setText(" ");a8.setEnabled(true);
        a9.setText(" ");a9.setEnabled(true);

        myTourn = false;
    }
}
